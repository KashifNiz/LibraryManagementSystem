package com.LibraryMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
